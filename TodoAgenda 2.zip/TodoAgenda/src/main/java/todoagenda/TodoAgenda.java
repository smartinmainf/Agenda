/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package todoagenda;


/**
 *
 * @author administrador
 */
public class TodoAgenda {

    public static void main(String[] args) {
             App app = new App();
             app.run();
    }
}
